backend_config = dict(
    type='tensorrt', common_config=dict(fp16_mode=False, max_workspace_size=0))
