# Statistics

## `subset_A`

### Temporal Consistency
![image](https://user-images.githubusercontent.com/29263416/228440318-f24136e5-7a26-4b28-bb74-6a448c900756.png)

### Instance Distribution
![image](https://user-images.githubusercontent.com/29263416/228441160-19d399c8-548c-4bef-8909-06ffcd0c027b.png)

### Centerline Property
![image](https://user-images.githubusercontent.com/29263416/228442761-5895e5b4-6d3a-4b90-8dbb-4ecfab98190e.png)

### Topology Distribution
![image](https://user-images.githubusercontent.com/29263416/228443434-a74085dc-28f8-400d-99a2-f0c67b49bf66.png)
