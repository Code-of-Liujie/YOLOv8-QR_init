from .intern_image import InternImage

__all__ = ['InternImage']
